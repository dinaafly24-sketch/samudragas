<?php
// Code Program Untuk Koneksi Ke Database
$server = "localhost";
$user = "root";
$password = "";
$nama_database = "samudragas";

$db = mysqli_connect($server, $user, $password, $nama_database);

if( !$db ){
    die("Gagal terhubung dengan database: " . mysqli_connect_error());
}
?>